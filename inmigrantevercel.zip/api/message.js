const db = require('../lib/supabase');

async function getVal(key, fallback) {
  const { data, error } = await db.from('app_state').select('value').eq('key', key).single();
  if (error || !data) return fallback;
  return data.value === null ? fallback : data.value;
}

async function setVal(key, value) {
  const { error } = await db.from('app_state').upsert({ key, value });
  if (error) throw new Error(error.message);
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const msg = req.body || {};

  try {
    switch (msg.type) {

      case 'new-order': {
        const { error } = await db.rpc('push_order', { o: msg.order });
        if (error) throw new Error(error.message);
        if (msg.order && msg.order.customer && msg.order.customer.phone) {
          const customers = await getVal('customers', []);
          const c = customers.find(x => x.phone === msg.order.customer.phone);
          if (c) {
            c.orders = (c.orders || 0) + 1;
            c.totalSpent = (c.totalSpent || 0) + msg.order.total;
            c.lastOrder = msg.order.ts;
            await setVal('customers', customers);
          }
        }
        return res.json({ ok: true });
      }

      case 'menu-update':
        await setVal('menu', msg.menu);
        return res.json({ ok: true });

      case 'drinks-update':
        await setVal('drinks', msg.drinks);
        return res.json({ ok: true });

      case 'stock-update':
        await setVal('stock', msg.stock);
        return res.json({ ok: true });

      case 'order-status': {
        const orders = await getVal('orders', []);
        const o = orders.find(x => x.id === msg.id);
        if (o) { o.status = msg.status; await setVal('orders', orders); }
        return res.json({ ok: true });
      }

      case 'order-delete': {
        const orders = (await getVal('orders', [])).filter(o => o.id !== msg.id);
        await setVal('orders', orders);
        return res.json({ ok: true });
      }

      case 'clear-entregados': {
        const orders = (await getVal('orders', [])).filter(o => o.status !== 'entregado');
        await setVal('orders', orders);
        return res.json({ ok: true });
      }

      case 'register-customer': {
        const customers = await getVal('customers', []);
        const c = msg.customer || {};
        if (c.phone && !customers.find(x => x.phone === c.phone)) {
          c.id = Date.now();
          c.orders = 0;
          c.totalSpent = 0;
          customers.push(c);
          await setVal('customers', customers);
        }
        return res.json({ type: 'customers-update', customers });
      }

      case 'find-customer': {
        const customers = await getVal('customers', []);
        const found = customers.find(x => x.phone === msg.phone) || null;
        return res.json({ type: 'customer-found', customer: found, _cb: msg._cb });
      }

      case 'get-customers': {
        const customers = await getVal('customers', []);
        return res.json({ type: 'customers-update', customers });
      }

      default:
        return res.status(400).json({ error: 'unknown message type' });
    }
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
};
