const db = require('../lib/supabase');

module.exports = async (req, res) => {
  const { data, error } = await db.from('app_state').select('key,value');
  if (error) return res.status(500).json({ error: error.message });
  const out = {};
  (data || []).forEach(r => { out[r.key] = r.value; });
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    orders:    out.orders    || [],
    menu:      out.menu      || null,
    drinks:    out.drinks    || null,
    stock:     out.stock     || {},
    customers: out.customers || []
  });
};
