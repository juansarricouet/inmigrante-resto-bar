-- ════════════════════════════════════════════════════════════
--  Inmigrante Resto Bar — setup de base de datos en Supabase
--  Pegar TODO este archivo en: Supabase → SQL Editor → Run
-- ════════════════════════════════════════════════════════════

-- Tabla única de estado (pedidos, menú, bebidas, stock, clientes)
create table if not exists app_state (
  key   text primary key,
  value jsonb not null
);

-- Bloquear acceso público directo (la app entra por el service role)
alter table app_state enable row level security;

-- Estado inicial
insert into app_state (key, value) values
  ('orders',    '[]'::jsonb),
  ('menu',      'null'::jsonb),
  ('drinks',    'null'::jsonb),
  ('stock',     '{}'::jsonb),
  ('customers', '[]'::jsonb)
on conflict (key) do nothing;

-- Insertar un pedido nuevo de forma atómica (mantiene máx. 1000 pedidos)
create or replace function push_order(o jsonb) returns void
language sql as $$
  update app_state
  set value = (
    select coalesce(jsonb_agg(elem order by ord), '[]'::jsonb)
    from (
      select elem, ord
      from jsonb_array_elements(jsonb_build_array(o) || value)
           with ordinality as t(elem, ord)
      where ord <= 1000
    ) s
  )
  where key = 'orders';
$$;
