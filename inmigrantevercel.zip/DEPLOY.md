# Desplegar en Vercel + Supabase (gratis)

La app detecta sola dónde está corriendo: con `npm start` local usa
WebSockets, y en Vercel usa las funciones serverless de `/api` con los
datos guardados en Supabase.

## 1. Crear la base de datos en Supabase

1. Entrá a https://supabase.com → **Start your project** → registrate
   (gratis, podés entrar con GitHub).
2. **New project**: poné un nombre (ej. `inmigrante`), una contraseña de
   base de datos (guardala) y región `South America (São Paulo)`.
3. Cuando el proyecto termine de crearse: menú izquierdo → **SQL Editor**
   → pegá TODO el contenido del archivo `supabase.sql` de este repo →
   botón **Run**. Tiene que decir "Success".
4. Menú izquierdo → **Project Settings** (engranaje) → **API**. Anotá dos
   cosas:
   - **Project URL** (ej. `https://abcdefg.supabase.co`)
   - **service_role key** (en "Project API keys", la que dice `service_role`
     — ojo, NO la `anon`)

## 2. Desplegar en Vercel

1. Entrá a https://vercel.com → **Sign Up** → **Continue with GitHub**.
2. **Add New… → Project** → importá el repo `inmigrante-resto-bar`.
3. ANTES de tocar Deploy, abrí **Environment Variables** y agregá:
   - `SUPABASE_URL` = la Project URL del paso anterior
   - `SUPABASE_SERVICE_ROLE_KEY` = la service_role key
4. Botón **Deploy**. En un minuto te da la URL, por ejemplo
   `https://inmigrante-resto-bar.vercel.app`:
   - Menú clientes: `https://TU-URL/bar-app.html` (o la raíz directamente)
   - Panel admin: `https://TU-URL/admin.html`

Nota: en Vercel la actualización entre pantallas es por sondeo cada
4 segundos (no instantánea como con WebSockets) — para un bar funciona
perfecto: un pedido nuevo aparece en el panel admin en menos de 4 segundos.

---

# Desplegar en EasyPanel

Guía para alojar Inmigrante Resto Bar en EasyPanel desde cero.

## 1. Conseguir un servidor (VPS)

EasyPanel es un panel que se instala en un servidor propio. Si perdiste el
acceso anterior, necesitás un VPS nuevo. Opciones económicas:

- **Hostinger VPS** (tiene plantilla con EasyPanel preinstalado — lo más fácil)
- **Hetzner** (~4 €/mes)
- **DigitalOcean** (~6 US$/mes)

Con 1 GB de RAM alcanza de sobra para esta app.

## 2. Instalar EasyPanel

Si el VPS no viene con EasyPanel preinstalado, conectate por SSH y ejecutá:

```bash
curl -sSL https://get.easypanel.io | sh
```

Después entrá a `https://IP-DEL-SERVIDOR:3000` y creá el usuario admin
(usá tu email actual).

## 3. Crear la app

1. En EasyPanel: **Create Project** → poné un nombre (ej. `inmigrante`).
2. Dentro del proyecto: **+ Service** → **App**.
3. En **Source** elegí **GitHub**, conectá tu cuenta de GitHub y seleccioná
   el repo `juansarricouet/inmigrante-resto-bar`, rama `main`.
4. En **Build** elegí **Dockerfile** (el repo ya lo trae).

## 4. Datos persistentes (importante)

Para que los pedidos, el menú y los clientes NO se borren en cada redeploy:

1. En la pestaña **Mounts** del servicio: agregá un **Volume**
   - Name: `data`
   - Mount path: `/data`
2. En la pestaña **Environment** agregá:
   ```
   DATA_DIR=/data
   ```

## 5. Dominio y puerto

1. En **Domains** agregá el dominio (o usá el subdominio gratuito que da
   EasyPanel) apuntando al puerto **3000**.
2. Activá HTTPS (EasyPanel lo hace solo con Let's Encrypt).

## 6. Deploy

Botón **Deploy**. En un minuto la app queda en línea:

- Menú clientes: `https://tu-dominio/bar-app.html`
- Panel admin: `https://tu-dominio/admin.html`

Cada vez que hagas push a `main` en GitHub podés redesplegar con un clic
(o activar auto-deploy en la pestaña **Source**).
